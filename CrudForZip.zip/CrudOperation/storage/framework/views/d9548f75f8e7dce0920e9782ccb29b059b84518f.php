
<div class="row">
	<div class="col-sm-2" >
		<?php echo Form::label('name', 'Employee Name'); ?>

	</div>
	<div class="col-sm-5">
		<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
			<?php echo Form::text('name',NULL, ['class'=>'form-control','id'=>'name','placeholder'=>'Enter employee Name']); ?>

			<?php echo $errors->first('name','<p class="help-block">:message</p>'); ?>

		</div>
	</div>
</div>
<div class="row">
	<div class="col-sm-2" >
		<?php echo Form::label('mobile', 'Mobile No.'); ?>

	</div>
	<div class="col-sm-5">
		<div class="form-group <?php echo e($errors->has('mobile') ? 'has-error' : ''); ?>">
			<?php echo Form::number('mobile',NULL, ['class'=>'form-control','id'=>'mobile','placeholder'=>'Enter mobile No.','maxlength'=>10]); ?>

			<?php echo $errors->first('mobile','<p class="help-block">:message</p>'); ?>

		</div>
	</div>
</div>
<div class="row">
	<div class="col-sm-2" >
		<?php echo Form::label('email', 'Email'); ?>

	</div>
	<div class="col-sm-5">
		<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
			<?php echo Form::text('email',NULL, ['class'=>'form-control','id'=>'email','placeholder'=>'Enter email']); ?>

			<?php echo $errors->first('email','<p class="help-block">:message</p>'); ?>

		</div>
	</div>
</div>

<div class="row">
	<div class="col-sm-2" >
		<?php echo Form::label('salary', 'Salary'); ?>

	</div>
	<div class="col-sm-5">
		<div class="form-group <?php echo e($errors->has('salary') ? 'has-error' : ''); ?>">
			<?php echo Form::number('salary',NULL, ['class'=>'form-control','id'=>'salary','placeholder'=>'Enter salary']); ?>

			<?php echo $errors->first('salary','<p class="help-block">:message</p>'); ?>

		</div>
	</div>
</div>
<div class="row">
	<div class="col-sm-2" >
		<?php echo Form::label('address', 'Address'); ?>

	</div>
	<div class="col-sm-5">
		<div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
			<?php echo Form::textarea('address', null, ['id' => 'address', 'rows' => 4, 'cols' => 54, 'style' => 'resize:none']); ?>

			<?php echo $errors->first('address','<p class="help-block">:message</p>'); ?>

		</div>
	</div>
</div>
<div class="row">
	<div class="col-sm-2" >
		
	</div>
	<div class="col-sm-5">
		<div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
			<?php echo Form::button(isset($employee) ? 'update' : 'save', ['class'=>'btn btn-success','type'=>'Submit']); ?>


			
		</div>
	</div>
</div>
