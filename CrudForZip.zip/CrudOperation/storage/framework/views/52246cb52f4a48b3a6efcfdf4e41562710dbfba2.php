<?php $__env->startSection('content'); ?>
<div class="container">

<div class="row">
<div class="col-sm-4">
<div class="full-right form-group">
<a href="item_menu" class="btn btn-primary">
Add Item Menu
</a>
</div>
</div>
<div class="col-sm-8">
<div class="full-right">
<select>
	<option> Menu Item List</option>
<?php if($item_menu->all()): ?>
<?php $__currentLoopData = $item_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</select>	
</div>
</div>
</div>

<div class="row">
<div class="col-sm-12">
<div class="full-right">
<h2>
Employee Details
</h2>
</div>
</div>
</div>
<table class="table table-bordered">
<tr>
<th width="80px">No</th>
<th>Employee Name</th>
<th>Email</th>
<th>Salary</th>
<th>Address</th>
<th width="140px" class="text-center" colspan="2">
<a href="<?php echo e(route('employees.create')); ?>" class="btn btn-success btn-sm">
<i class="glyphicon glyphicon-plus"></i>
</a>
</th>
</tr>
<?php $no=1; ?>
<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($no++); ?></td>
<td><?php echo e($value->name); ?></td>
<td><?php echo e($value->email); ?></td>
<td><?php echo e($value->salary); ?></td>
<td><?php echo e($value->address); ?></td>
<td>

<a class="btn btn-primary btn-sm" href="<?php echo e(route('employees.edit',$value->id)); ?>" >
<i class="glyphicon glyphicon-pencil"></i>
</a>
</td>
<td>
<?php echo Form::open(['method'=>'DELETE','route'=>['employees.destroy',$value->id],'style'=>'display:inline']); ?>

<button type="submit" style="display: inline;" class="btn btn-danger btn sm"><i class="glyphicon glyphicon-minus"></i></button>
<?php echo Form::close(); ?>

</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>