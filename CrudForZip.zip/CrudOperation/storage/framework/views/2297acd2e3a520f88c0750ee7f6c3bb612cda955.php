<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-6 col-md-offset-4"><b>Add Employee Details</b></div>
	<p>&nbsp;</p>
	<div class="col-md-6 col-md-offset-3">
		<?php echo Form::model($employee,['route'=>['employees.update',$employee->id],'method'=>'PATCH']); ?>

		<?php echo $__env->make('admin.form_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo Form::close(); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>