<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row pull-rigth">
<div class="col-sm-12">
<div>

<b>Add Item Menu
</b>
<p>&nbsp;</p>
</div>
</div>
</div>
<div class="row">
<form action="addItemMenu" method="post">
<?php echo e(csrf_field()); ?>

<div class="row">
<div class="col-sm-2" >
<label><b>Item Name</b></label>
</div>
<div class="col-sm-5">
<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
<input type="text" name="name">

</div>
</div>
</div>
<div class="row">
<div class="col-sm-2" >
</div>
<div class="col-sm-5">

<input type="submit" class="btn btn-primary" value="Add Item">

</div>
</div>
</div>

</form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>