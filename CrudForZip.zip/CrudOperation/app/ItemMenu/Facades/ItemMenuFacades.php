<?php

namespace App\ItemMenu\Facades;

use Illuminate\Support\Facades\Facade;

class ItemMenuFacades extends Facade {
protected static function getFacadeAccessor() {

return 'ItemMenu';


}
}


?>